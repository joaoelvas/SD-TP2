package sd.tp1.srv;

@SuppressWarnings("serial")
public class NoPictureFoundException extends Exception {

	public NoPictureFoundException(String message) {
		super(message);
	}
}
