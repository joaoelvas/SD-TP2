package sd.tp1.srv;

@SuppressWarnings("serial")
public class InfoNotFoundException extends Exception {
	public InfoNotFoundException(String message) {
		super(message);
	}
}
